<?php return [
    'plugin' => [
        'name' => 'Game',
        'description' => 'Create and setting game'
    ]
];