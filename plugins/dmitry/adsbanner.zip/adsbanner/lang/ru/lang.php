<?php return [
    'plugin' => [
        'name' => 'ADS Banner',
        'description' => 'add image in ads banner'
    ]
];